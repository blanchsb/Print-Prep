# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Print Prep",
    "author" : "Shawn Blanch (blanchsb), made with Serpens", 
    "description" : "Helps in preparing 3D Print Objects: making keyed cuts, orienting objects, adding printer proxy, etc.",
    "blender" : (5, 1, 1),
    "version" : (5, 1, 1),
    "location" : "VIEW3D",
    "warning" : "",
    "doc_url": "https://www.youtube.com/channel/UCgzsjoHGftzv4DSoyi3E-Kw", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os
import math
from mathutils import Vector
from mathutils import Matrix




def string_to_int(value):
    if value.isdigit():
        return int(value)
    return 0


def string_to_icon(value):
    if value in bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys():
        return bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items[value].value
    return string_to_int(value)


addon_keymaps = {}
_icons = None
ops_cut_selected_from_active = {'sna_selected_objects': [], 'sna_active_object_original': None, 'sna_duplicate_object': None, }
ops_material_settings = {'sna_selected_objects': [], 'sna_active_object': None, }
ops_rotate_and_move_to_origin = {'sna_var_face_align_was_active': False, 'sna_var_mesh_onjects': [], 'sna_var_rotation_mode': '', }


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def find_areas_of_type(screen, area_type):
    areas = []
    for area in screen.areas:
        if area.type == area_type:
            areas.append(area)
    return areas


def find_area_by_type(screen, area_type, index):
    areas = find_areas_of_type(screen, area_type)
    if areas:
        return areas[index]
    return None


def sna_update_sna_activate_face_align_2CC3A(self, context):
    sna_updated_prop = self.sna_activate_face_align
    if sna_updated_prop:
        bpy.context.scene.sna_original_snap_elements_base = bpy.context.scene.tool_settings.snap_elements_base
        bpy.context.scene.sna_original_origin_state = bpy.context.scene.tool_settings.use_transform_data_origin
        bpy.context.scene.sna_original_use_snap = bpy.context.scene.tool_settings.use_snap
        bpy.context.scene.sna_original_snap_align_rotation = bpy.context.scene.tool_settings.use_snap_align_rotation
        bpy.context.scene.sna_original_use_snap_translate = bpy.context.scene.tool_settings.use_snap_translate
        bpy.context.scene.tool_settings.snap_elements_base = set(['FACE_MIDPOINT'])
        bpy.context.scene.tool_settings.use_transform_data_origin = True
        bpy.context.scene.tool_settings.use_snap = True
        bpy.context.scene.tool_settings.use_snap_align_rotation = True
        bpy.context.scene.tool_settings.use_snap_translate = True
    else:
        bpy.context.scene.tool_settings.snap_elements_base = bpy.context.scene.sna_original_snap_elements_base
        bpy.context.scene.tool_settings.use_transform_data_origin = bpy.context.scene.sna_original_origin_state
        bpy.context.scene.tool_settings.use_snap = bpy.context.scene.sna_original_use_snap
        bpy.context.scene.tool_settings.use_snap_align_rotation = bpy.context.scene.sna_original_snap_align_rotation
        bpy.context.scene.tool_settings.use_snap_translate = bpy.context.scene.sna_original_use_snap_translate
    if bpy.context and bpy.context.screen:
        for a in bpy.context.screen.areas:
            a.tag_redraw()


def sna_update_sna_toggle_show_hide_889F2(self, context):
    sna_updated_prop = self.sna_toggle_show_hide
    self.hide_set(state=(not self.hide_get(view_layer=bpy.context.view_layer, )), view_layer=bpy.context.view_layer, )


class SNA_OT_Append_Printer_Proxy_160Ed(bpy.types.Operator):
    bl_idname = "sna.append_printer_proxy_160ed"
    bl_label = "Append Printer Proxy"
    bl_description = "Append a Bambu Lab A1 printer proxy collection to the scene - made by blanchsb"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        before_data = list(bpy.data.collections)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'startup.blend') + r'\Collection', filename='Printer.Collection.Main', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.collections)))
        appended_9F9EE = None if not new_data else new_data[0]
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Use_Active_To_Cut_Selected_B4720(bpy.types.Operator):
    bl_idname = "sna.use_active_to_cut_selected_b4720"
    bl_label = "Use Active to Cut Selected"
    bl_description = "Duplicates the active object as a cutter for selected objects. \nUse cutter settings on the N-Panel to customize the cutter. \nOptions include adding solidify gap or shrinkage, boolean solver, using materials in the cutter, and changing the material color."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Requires at least two objects with one active and the other selected')
        return not False

    def execute(self, context):
        sna_fn_cut_selected_from_active_C41FF()
        self.report({'INFO'}, message='Applied modifiers objects')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_cut_selected_from_active_C41FF():
    ops_cut_selected_from_active['sna_active_object_original'] = None
    ops_cut_selected_from_active['sna_selected_objects'] = []
    ops_cut_selected_from_active['sna_duplicate_object'] = None
    ops_cut_selected_from_active['sna_selected_objects'] = list(bpy.context.view_layer.objects.selected)
    ops_cut_selected_from_active['sna_active_object_original'] = bpy.context.view_layer.objects.active
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = ops_cut_selected_from_active['sna_active_object_original']
    bpy.context.view_layer.objects.active.select_set(state=True, view_layer=bpy.context.view_layer, )
    bpy.ops.object.duplicate_move()
    bpy.context.view_layer.objects.active.name = getattr(ops_cut_selected_from_active['sna_active_object_original'], 'name', None) + bpy.context.preferences.addons[__package__].preferences.sna_cutter_suffix
    ops_cut_selected_from_active['sna_duplicate_object'] = bpy.context.view_layer.objects.active
    bpy.ops.object.modifier_add(type='SOLIDIFY', use_selected_objects=False)
    bpy.context.view_layer.objects.active.modifiers.active.thickness = bpy.context.scene.sna_cutter_gap
    if bpy.context.scene.sna_gap_direction == "Grow":
        bpy.context.view_layer.objects.active.modifiers.active.offset = 1.0
    elif bpy.context.scene.sna_gap_direction == "Shrink":
        bpy.context.view_layer.objects.active.modifiers.active.offset = -1.0
    else:
        pass
    bpy.context.view_layer.objects.active.modifiers.active.use_even_offset = bpy.context.scene.sna_even_thickness
    bpy.context.view_layer.objects.active.modifiers.active.use_rim_only = bpy.context.scene.sna_cut_from_outside_only_rim
    bpy.context.view_layer.objects.active.display_type = 'BOUNDS'
    sna_fn_add_material_to_cutter_53CE5()
    bpy.context.view_layer.objects.active.hide_render = bpy.context.scene.sna_hide_from_render
    bpy.context.view_layer.objects.active.hide_viewport = bpy.context.scene.sna_hide_from_viewport
    sna_fn_subfn_cut_selected_7FCE5()
    sna_fn_generated_affected_objects_collection_CD352(getattr(ops_cut_selected_from_active['sna_duplicate_object'], 'name', None))
    sna_fn_subfn_restore_selected_and_active_78DFC()


def sna_fn_subfn_cut_selected_7FCE5():
    for i_63E76 in range(len(ops_cut_selected_from_active['sna_selected_objects'])-1,-1,-1):
        bpy.ops.object.select_all(action='DESELECT')
        if (ops_cut_selected_from_active['sna_selected_objects'][i_63E76] != ops_cut_selected_from_active['sna_active_object_original']):
            bpy.context.view_layer.objects.active = ops_cut_selected_from_active['sna_selected_objects'][i_63E76]
            bpy.context.view_layer.objects.active.select_set(state=True, view_layer=bpy.context.view_layer, )
            bpy.ops.object.modifier_add(type='BOOLEAN', use_selected_objects=False)
            if bpy.context.scene.sna_boolean_solver == "Manifold":
                bpy.context.view_layer.objects.active.modifiers.active.solver = 'MANIFOLD'
            elif bpy.context.scene.sna_boolean_solver == "Exact":
                bpy.context.view_layer.objects.active.modifiers.active.solver = 'EXACT'
            elif bpy.context.scene.sna_boolean_solver == "Float":
                bpy.context.view_layer.objects.active.modifiers.active.solver = 'FLOAT'
            else:
                pass
            if bpy.context.scene.sna_transfer_material == "Transfer":
                bpy.context.view_layer.objects.active.modifiers.active.material_mode = 'TRANSFER'
            elif bpy.context.scene.sna_transfer_material == "Index Based":
                bpy.context.view_layer.objects.active.modifiers.active.material_mode = 'INDEX'
            else:
                pass
            bpy.context.view_layer.objects.active.modifiers.active.object = ops_cut_selected_from_active['sna_duplicate_object']


def sna_fn_subfn_restore_selected_and_active_78DFC():
    bpy.ops.object.select_all(action='DESELECT')
    for i_5D553 in range(len(ops_cut_selected_from_active['sna_selected_objects'])-1,-1,-1):
        bpy.context.view_layer.objects.active = ops_cut_selected_from_active['sna_selected_objects'][i_5D553]
        exec('bpy.context.view_layer.objects.active.select_set(state=True, view_layer=bpy.context.view_layer, )')
    bpy.context.view_layer.objects.active = ops_cut_selected_from_active['sna_active_object_original']


def sna_fn_add_material_to_cutter_53CE5():
    if bpy.context.scene.sna_add_material_to_cutter:
        if (property_exists("bpy.data.materials", globals(), locals()) and 'Cutter.Material' in bpy.data.materials):
            pass
        else:
            before_data = list(bpy.data.materials)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Cutter Asset File.blend') + r'\Material', filename='Cutter.Material', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.materials)))
            appended_43924 = None if not new_data else new_data[0]
        bpy.context.view_layer.objects.active.data.materials.clear()
        bpy.context.view_layer.objects.active.data.materials.append(material=bpy.data.materials['Cutter.Material'], )
        for i_332E5 in range(len(bpy.context.view_layer.objects.active.data.materials)):
            setattr(bpy.context.view_layer.objects.active.data.materials[i_332E5].node_tree.nodes['Emission'].inputs[0], 'default_value', bpy.context.scene.sna_material_color)
            break


class SNA_OT_Remove_Cutter_66191(bpy.types.Operator):
    bl_idname = "sna.remove_cutter_66191"
    bl_label = "Remove Cutter"
    bl_description = "Remove the Cutter from the Object"
    bl_options = {"REGISTER", "UNDO"}
    sna_cutter_object: bpy.props.StringProperty(name='Cutter Object', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)
    sna_affected_object: bpy.props.StringProperty(name='Affected Object', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_4A41A in range(len(bpy.data.objects[self.sna_affected_object].modifiers)-1,-1,-1):
            if (bpy.data.objects[self.sna_affected_object].modifiers[i_4A41A].type == 'BOOLEAN'):
                if bpy.data.objects[self.sna_affected_object].modifiers[i_4A41A].object:
                    if (getattr(bpy.data.objects[self.sna_affected_object].modifiers[i_4A41A].object, 'name', None) == self.sna_cutter_object):
                        exec("bpy.data.objects['" + getattr(bpy.data.objects[self.sna_affected_object], 'name', None) + "'].modifiers.remove(modifier=bpy.data.objects['" + getattr(bpy.data.objects[self.sna_affected_object], 'name', None) + "'].modifiers['" + bpy.data.objects[self.sna_affected_object].modifiers[i_4A41A].name + "'])")
        for i_F7B13 in range(len(bpy.data.objects[self.sna_cutter_object].sna_affected_objects_collection)-1,-1,-1):
            if (self.sna_affected_object == bpy.data.objects[self.sna_cutter_object].sna_affected_objects_collection[i_F7B13].affected_object):
                for i_8A64C in range(len(bpy.data.objects[self.sna_cutter_object].sna_affected_objects_collection)):
                    if bpy.data.objects[self.sna_cutter_object].sna_affected_objects_collection[i_8A64C] == bpy.data.objects[self.sna_cutter_object].sna_affected_objects_collection[i_F7B13]:
                        bpy.data.objects[self.sna_cutter_object].sna_affected_objects_collection.remove(i_8A64C)
                        break
                if (bpy.data.objects[self.sna_cutter_object].sna_affected_objects_coll_indx < 1):
                    pass
                else:
                    bpy.data.objects[self.sna_cutter_object].sna_affected_objects_coll_indx = int(bpy.data.objects[self.sna_cutter_object].sna_affected_objects_coll_indx - 1.0)
        self.report({'INFO'}, message='Removed Cutter: ' + self.sna_cutter_object + ' from: ' + self.sna_affected_object)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Delete_And_Remove_Cutter_From_All_Affected_Objects_B38B1(bpy.types.Operator):
    bl_idname = "sna.delete_and_remove_cutter_from_all_affected_objects_b38b1"
    bl_label = "Delete and Remove Cutter from all Affected Objects"
    bl_description = "Deletes the cutter object and removes it as the cutter for all affected objects"
    bl_options = {"REGISTER", "UNDO"}
    sna_cutter_object: bpy.props.StringProperty(name='Cutter Object', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Object name must have proper suffix defined in add-on preferences')
        return not False

    def execute(self, context):
        for i_1CAFA in range(len(bpy.data.objects)-1,-1,-1):
            for i_4A6A7 in range(len(bpy.data.objects[i_1CAFA].modifiers)-1,-1,-1):
                if (bpy.data.objects[i_1CAFA].modifiers[i_4A6A7].type == 'BOOLEAN'):
                    if bpy.data.objects[i_1CAFA].modifiers[i_4A6A7].object:
                        if (getattr(bpy.data.objects[i_1CAFA].modifiers[i_4A6A7].object, 'name', None) == self.sna_cutter_object):
                            exec("bpy.data.objects['" + getattr(bpy.data.objects[i_1CAFA], 'name', None) + "'].modifiers.remove(modifier=bpy.data.objects['" + getattr(bpy.data.objects[i_1CAFA], 'name', None) + "'].modifiers['" + bpy.data.objects[i_1CAFA].modifiers[i_4A6A7].name + "'])")
        exec("bpy.data.objects.remove(object=bpy.data.objects['" + self.sna_cutter_object + "'], do_unlink=True)")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Select_Affected_Objects_Of_Cutter_231Cd(bpy.types.Operator):
    bl_idname = "sna.select_affected_objects_of_cutter_231cd"
    bl_label = "Select Affected Objects of Cutter"
    bl_description = "Select all affected objects of the Cutter Object"
    bl_options = {"REGISTER", "UNDO"}
    sna_cutter_object: bpy.props.StringProperty(name='Cutter Object', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Object name must have proper suffix defined in add-on preferences')
        return not False

    def execute(self, context):
        sna_fn_generated_affected_objects_collection_CD352(self.sna_cutter_object)
        bpy.ops.object.select_all(action='DESELECT')
        for i_130E3 in range(len(bpy.data.objects)-1,-1,-1):
            for i_3DAF4 in range(len(bpy.data.objects[i_130E3].modifiers)-1,-1,-1):
                if (bpy.data.objects[i_130E3].modifiers[i_3DAF4].type == 'BOOLEAN'):
                    if bpy.data.objects[i_130E3].modifiers[i_3DAF4].object:
                        if (getattr(bpy.data.objects[i_130E3].modifiers[i_3DAF4].object, 'name', None) == self.sna_cutter_object):
                            bpy.context.view_layer.objects.active = bpy.data.objects[i_130E3]
                            exec("bpy.context.view_layer.objects['" + getattr(bpy.data.objects[i_130E3], 'name', None) + "'].select_set(state=True, view_layer=bpy.context.view_layer)")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_generated_affected_objects_collection_CD352(Cutter_Object):
    bpy.context.view_layer.objects.active.sna_affected_objects_collection.clear()
    if bpy.context and bpy.context.screen:
        for a in bpy.context.screen.areas:
            a.tag_redraw()
    bpy.context.view_layer.objects.active.sna_affected_objects_coll_indx = 0
    for i_174E2 in range(len(bpy.data.objects)-1,-1,-1):
        if bpy.data.objects[i_174E2].type == 'MESH':
            if bpy.data.objects[i_174E2].modifiers:
                for i_51EE1 in range(len(bpy.data.objects[i_174E2].modifiers)-1,-1,-1):
                    if (bpy.data.objects[i_174E2].modifiers[i_51EE1].type == 'BOOLEAN'):
                        if bpy.data.objects[i_174E2].modifiers[i_51EE1].object:
                            if (getattr(bpy.data.objects[i_174E2].modifiers[i_51EE1].object, 'name', None) == Cutter_Object):
                                if (property_exists("bpy.data.objects[Cutter_Object].sna_affected_objects_collection", globals(), locals()) and getattr(bpy.data.objects[i_174E2], 'name', None) in bpy.data.objects[Cutter_Object].sna_affected_objects_collection):
                                    pass
                                else:
                                    item_B8C99 = bpy.data.objects[Cutter_Object].sna_affected_objects_collection.add()
                                    item_B8C99.affected_object = getattr(bpy.data.objects[i_174E2], 'name', None)
                                    item_B8C99.cutter_object = Cutter_Object


class SNA_OT_Select_Affected_Object_3E0D0(bpy.types.Operator):
    bl_idname = "sna.select_affected_object_3e0d0"
    bl_label = "Select Affected Object"
    bl_description = "Select the Affected Object"
    bl_options = {"REGISTER", "UNDO"}
    sna_object: bpy.props.StringProperty(name='Object', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')
        exec("bpy.context.view_layer.objects['" + self.sna_object + "'].select_set(state=True, view_layer=bpy.context.view_layer)")
        bpy.context.view_layer.objects.active = bpy.data.objects[self.sna_object]
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Update_Cutter_Affected_Objects_Collection_Edbc7(bpy.types.Operator):
    bl_idname = "sna.update_cutter_affected_objects_collection_edbc7"
    bl_label = "Update Cutter Affected Objects Collection"
    bl_description = "Updates the collection for all of the Affected Objects of the Cutter Object"
    bl_options = {"REGISTER", "UNDO"}
    sna_cutter_object: bpy.props.StringProperty(name='Cutter Object', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fn_generated_affected_objects_collection_CD352(self.sna_cutter_object)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Or_Update_Fdm_Material_37519(bpy.types.Operator):
    bl_idname = "sna.add_or_update_fdm_material_37519"
    bl_label = "Add or Update FDM Material"
    bl_description = "WARNING: Removes and replaces existing materials. \n\nAdd an FDM material to the selected object(s). This will also add a color attribute. If the material exists then it will update the color attritbute color from the custom color on the N-Panel"
    bl_options = {"REGISTER", "UNDO"}
    sna_custom_color: bpy.props.FloatVectorProperty(name='custom_color', description='the custom color of the color attribute', options={'SKIP_SAVE', 'HIDDEN'}, size=3, default=(1.0, 1.0, 1.0), subtype='COLOR', unit='NONE', soft_min=0.0, soft_max=1.0, step=1, precision=1)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Select an Object')
        return not (not bpy.context.view_layer.objects.selected)

    def execute(self, context):
        ops_material_settings['sna_active_object'] = None
        ops_material_settings['sna_selected_objects'] = []
        ops_material_settings['sna_selected_objects'] = list(bpy.context.view_layer.objects.selected)
        ops_material_settings['sna_active_object'] = bpy.context.view_layer.objects.active
        if (property_exists("bpy.data.materials", globals(), locals()) and 'Printer.FDM_Plastic_Printed' in bpy.data.materials):
            pass
        else:
            before_data = list(bpy.data.materials)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'startup.blend') + r'\Material', filename='Printer.FDM_Plastic_Printed', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.materials)))
            appended_1FEC0 = None if not new_data else new_data[0]
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = ops_material_settings['sna_active_object']
        for i_EDF23 in range(len(ops_material_settings['sna_selected_objects'])-1,-1,-1):
            if ops_material_settings['sna_selected_objects'][i_EDF23].type == 'MESH':
                ops_material_settings['sna_selected_objects'][i_EDF23].data.materials.clear()
                ops_material_settings['sna_selected_objects'][i_EDF23].data.materials.append(material=bpy.data.materials['Printer.FDM_Plastic_Printed'], )
                object_i = ops_material_settings['sna_selected_objects'][i_EDF23]
                custom_color = (self.sna_custom_color[0], self.sna_custom_color[1], self.sna_custom_color[2], 1.0)
                #Cred where credit is due. This was made with the assistance of ChatGPT and customized to fit how I wanted it to work with Serpens.
                obj = object_i
                mesh = obj.data
                # Create or get a POINT-domain color attribute
                attr = mesh.color_attributes.get("Color")
                if not attr:
                    attr = mesh.color_attributes.new(
                        name="Color",
                        type='FLOAT_COLOR',
                        domain='POINT'
                    )
                #Set the color attribute as the active color and active render color.
                mesh.color_attributes.active_color = attr
                mesh.color_attributes.render_color_index = mesh.color_attributes.active_color_index
                #Set colors on each vertex from the custom color
                for i in range(len(attr.data)):
                    attr.data[i].color = custom_color
                mesh.update()
            ops_material_settings['sna_selected_objects'][i_EDF23].select_set(state=True, )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Smart_Pack_Beds_B19Df(bpy.types.Operator):
    bl_idname = "sna.smart_pack_beds_b19df"
    bl_label = "Smart Pack Beds"
    bl_description = "Smartly pack mesh objects to print bed using color attribute colors to group objects by same color"
    bl_options = {"REGISTER", "UNDO"}
    sna_object_spacing: bpy.props.FloatProperty(name='Object Spacing', description='Gap between objects', options={'HIDDEN'}, default=4.0, subtype='DISTANCE', unit='LENGTH', min=0.0, step=10, precision=0)
    sna_group_spacing: bpy.props.FloatProperty(name='Group Spacing', description='Spacing between object groups', options={'HIDDEN'}, default=73.0, subtype='DISTANCE', unit='LENGTH', min=0.0, soft_min=20.0, soft_max=80.0, step=10, precision=0)
    sna_bed_edge_spacing: bpy.props.FloatProperty(name='Bed Edge Spacing', description='Spacing from edge of print bed', options={'HIDDEN'}, default=4.0, subtype='DISTANCE', unit='LENGTH', min=0.0, soft_max=10.0, step=10, precision=0)
    sna_bed_length_x: bpy.props.FloatProperty(name='Bed Length X', description='Width of the Print Bed', options={'HIDDEN'}, default=256.0, subtype='DISTANCE', unit='LENGTH', min=1.0, step=10, precision=0)
    sna_bed_length_y: bpy.props.FloatProperty(name='Bed Length Y', description='Height of the Print Bed', options={'HIDDEN'}, default=256.0, subtype='DISTANCE', unit='LENGTH', min=1.0, step=10, precision=0)
    sna_color_match: bpy.props.FloatProperty(name='Color Match', description='', options={'HIDDEN'}, default=99.0, subtype='PERCENTAGE', unit='NONE', min=0.0, max=100.0, step=10, precision=1)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Requires selected objects')
        return not (not bpy.context.view_layer.objects.selected)

    def execute(self, context):
        sna_fn_move_to_world_origin_and_clear_rotation_D1207(True, self.sna_object_spacing, self.sna_group_spacing, self.sna_bed_edge_spacing, self.sna_bed_length_x, self.sna_bed_length_y, self.sna_color_match)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Move_To_World_Origin_And_Clear_Rotation_F7F82(bpy.types.Operator):
    bl_idname = "sna.move_to_world_origin_and_clear_rotation_f7f82"
    bl_label = "Move to World Origin and Clear Rotation"
    bl_description = "Clear mesh object(s) rotation and move to world origin"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('Requires selected objects')
        return not (not bpy.context.view_layer.objects.selected)

    def execute(self, context):
        sna_fn_move_to_world_origin_and_clear_rotation_D1207(False, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fn_move_to_world_origin_and_clear_rotation_D1207(pack_objects, object_padding, group_padding, bed_padding, bed_x_size, bed_y_size, color_match_pct):
    ops_rotate_and_move_to_origin['sna_var_face_align_was_active'] = False
    ops_rotate_and_move_to_origin['sna_var_mesh_onjects'] = []
    if bpy.context.scene.sna_use_keyframes:
        bpy.context.scene.frame_current = bpy.context.scene.sna_print_prep_start_frame
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()

        def delayed_306FB():
            for i_F9D03 in range(len(bpy.context.view_layer.objects.selected)-1,-1,-1):
                if bpy.context.view_layer.objects.selected[i_F9D03].type == 'MESH':
                    success_31A21 = bpy.context.view_layer.objects.selected[i_F9D03].keyframe_delete(data_path='location', frame=bpy.context.scene.sna_print_prep_start_frame, )
                    success_DD491 = bpy.context.view_layer.objects.selected[i_F9D03].keyframe_delete(data_path='location', frame=bpy.context.scene.sna_print_prep_end_frame, )
                    success_98B95 = bpy.context.view_layer.objects.selected[i_F9D03].keyframe_delete(data_path='rotation_euler', frame=bpy.context.scene.sna_print_prep_start_frame, )
                    success_CA5B4 = bpy.context.view_layer.objects.selected[i_F9D03].keyframe_delete(data_path='rotation_euler', frame=bpy.context.scene.sna_print_prep_end_frame, )
            if bpy.context and bpy.context.screen:
                for a in bpy.context.screen.areas:
                    a.tag_redraw()
        bpy.app.timers.register(delayed_306FB, first_interval=0.10000000149011612)

    def delayed_7B5D0():
        if bpy.context.scene.sna_activate_face_align:
            bpy.context.scene.sna_activate_face_align = False
            ops_rotate_and_move_to_origin['sna_var_face_align_was_active'] = True
        for i_50222 in range(len(bpy.context.view_layer.objects.selected)-1,-1,-1):
            if bpy.context.view_layer.objects.selected[i_50222].type == 'MESH':
                if bpy.context.scene.sna_use_keyframes:
                    success_742B3 = bpy.context.view_layer.objects.selected[i_50222].keyframe_insert(data_path='location', frame=bpy.context.scene.sna_print_prep_start_frame, )
                    bpy.context.view_layer.objects.selected[i_50222].rotation_mode = 'XYZ'
                    success_10E9E = bpy.context.view_layer.objects.selected[i_50222].keyframe_insert(data_path='rotation_euler', frame=bpy.context.scene.sna_print_prep_start_frame, )
                ops_rotate_and_move_to_origin['sna_var_mesh_onjects'].append(bpy.context.view_layer.objects.selected[i_50222])
                bpy.context.view_layer.objects.selected[i_50222].location = (0.0, 0.0, 0.0)
                bpy.context.view_layer.objects.selected[i_50222].rotation_mode = 'XYZ'
                bpy.context.view_layer.objects.selected[i_50222].rotation_euler = (math.radians(180.0), 0.0, 0.0)
        if pack_objects:
            mesh_objs = ops_rotate_and_move_to_origin['sna_var_mesh_onjects']
            object_spacing = object_padding
            group_spacing = group_padding
            bed_spacing = bed_padding
            bed_width = bed_x_size
            bed_height = bed_y_size
            color_similarity = float(color_match_pct / 100.0)
            #Credit where credit is due. This part was made with the help of CoPilot and I modified variables for added dynamic control
            # ------------------------------------------------------------
            # USER SETTINGS
            # ------------------------------------------------------------
            #color_attribute="Color",
            color_similarity_threshold=color_similarity
            selected = mesh_objs
            groups = group_objects_by_color(
                selected,
                attribute_name="Color",
                threshold=color_similarity_threshold
            )
            layout_groups(
                groups,
                bed_width=bed_width,
                bed_height=bed_height,
                edge_padding=bed_spacing,
                group_spacing_x=group_spacing,
                group_spacing_y=group_spacing,
                object_padding=object_spacing
            )
            #End CoPilot help, back to Serpens
        if bpy.context.scene.sna_use_keyframes:
            for i_C375B in range(len(ops_rotate_and_move_to_origin['sna_var_mesh_onjects'])-1,-1,-1):
                success_3F90F = ops_rotate_and_move_to_origin['sna_var_mesh_onjects'][i_C375B].keyframe_insert(data_path='location', frame=bpy.context.scene.sna_print_prep_end_frame, )
                success_C502D = ops_rotate_and_move_to_origin['sna_var_mesh_onjects'][i_C375B].keyframe_insert(data_path='rotation_euler', frame=bpy.context.scene.sna_print_prep_end_frame, )
            bpy.context.scene.frame_current = bpy.context.scene.sna_print_prep_end_frame
        if ops_rotate_and_move_to_origin['sna_var_face_align_was_active']:
            bpy.context.scene.sna_activate_face_align = True
            ops_rotate_and_move_to_origin['sna_var_face_align_was_active'] = False
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
    bpy.app.timers.register(delayed_7B5D0, first_interval=0.10000000149011612)


class SNA_OT_Select_Cutter_Object_D9844(bpy.types.Operator):
    bl_idname = "sna.select_cutter_object_d9844"
    bl_label = "Select Cutter Object"
    bl_description = "Select the Cutter Object affecting the Active Object (turns off Hide & Hide Select in order to see the object)"
    bl_options = {"REGISTER", "UNDO"}
    sna_object: bpy.props.StringProperty(name='Object', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = bpy.data.objects[self.sna_object]
        bpy.context.view_layer.objects[self.sna_object].hide_viewport = False
        bpy.context.view_layer.objects[self.sna_object].hide_select = False
        exec("bpy.context.view_layer.objects['" + self.sna_object + "'].hide_set(state=False, view_layer=bpy.context.view_layer)")
        exec("bpy.context.view_layer.objects['" + self.sna_object + "'].select_set(state=True, view_layer=bpy.context.view_layer)")
        self.report({'INFO'}, message='Selected Cutter: ' + self.sna_object)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Deselect_Object_Dbfbd(bpy.types.Operator):
    bl_idname = "sna.deselect_object_dbfbd"
    bl_label = "Deselect Object"
    bl_description = "Deselect the object"
    bl_options = {"REGISTER", "UNDO"}
    sna_selected_object: bpy.props.StringProperty(name='selected_object', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.objects[self.sna_selected_object].select_set(state=False, )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Activate_Object_81920(bpy.types.Operator):
    bl_idname = "sna.activate_object_81920"
    bl_label = "Activate Object"
    bl_description = "Make the object the active object"
    bl_options = {"REGISTER", "UNDO"}
    sna_selected_object: bpy.props.StringProperty(name='selected_object', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active = bpy.data.objects[self.sna_selected_object]
        bpy.data.objects[self.sna_selected_object].select_set(state=True, )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Units_And_3D_View_Clipping_Be2D0(bpy.types.Operator):
    bl_idname = "sna.set_units_and_3d_view_clipping_be2d0"
    bl_label = "Set Units and 3D View Clipping"
    bl_description = "Set up scene unit settings and viewport clipping \n  System = Metric \n  Length = Meters \n  Scale = 1.0 \n  3D View Clip Start = 1 \n  3D View Clip End = 10,000 \n  If a scene camera is set then camera clip settings will also be set"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.unit_settings.system = 'METRIC'
        bpy.context.scene.unit_settings.scale_length = 1.0
        bpy.context.scene.unit_settings.length_unit = 'METERS'
        find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces[0].clip_start = 1.0
        find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces[0].clip_end = 10000.0
        if bpy.context.scene.camera:
            bpy.context.scene.camera.data.clip_start = 1.0
            bpy.context.scene.camera.data.clip_end = 10000.0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


from mathutils import Euler
#Credit where credit is due. This part was made with the help of CoPilot and I modified variables for added dynamic control
# ------------------------------------------------------------
# BOUNDING BOX
# ------------------------------------------------------------


def get_world_bbox_size(obj):
    world_corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    min_x = min(v.x for v in world_corners)
    max_x = max(v.x for v in world_corners)
    min_y = min(v.y for v in world_corners)
    max_y = max(v.y for v in world_corners)
    return max_x - min_x, max_y - min_y


# ------------------------------------------------------------
# MAXRECTS IMPLEMENTATION
# ------------------------------------------------------------
class Rect:

    def __init__(self, x, y, width, height, obj=None):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.obj = obj


class MaxRectsBin:

    def __init__(self, width, height):
        self.bin_width = width
        self.bin_height = height
        self.free_rectangles = [Rect(0, 0, width, height)]
        self.used_rectangles = []

    def find_position(self, width, height):
        best_node = None
        best_short_side = float("inf")
        for free in self.free_rectangles:
            if free.width >= width and free.height >= height:
                leftover_w = free.width - width
                leftover_h = free.height - height
                short_side = min(leftover_w, leftover_h)
                if short_side < best_short_side:
                    best_short_side = short_side
                    best_node = Rect(free.x, free.y, width, height)
        return best_node

    def split_free_rect(self, free_rect, placed_rect):
        new_rects = []
        # Vertical splits
        if placed_rect.x < free_rect.x + free_rect.width and placed_rect.x + placed_rect.width > free_rect.x:
            # Top
            if placed_rect.y > free_rect.y:
                new_rects.append(Rect(
                    free_rect.x,
                    free_rect.y,
                    free_rect.width,
                    placed_rect.y - free_rect.y
                ))
            # Bottom
            if placed_rect.y + placed_rect.height < free_rect.y + free_rect.height:
                new_rects.append(Rect(
                    free_rect.x,
                    placed_rect.y + placed_rect.height,
                    free_rect.width,
                    (free_rect.y + free_rect.height) - (placed_rect.y + placed_rect.height)
                ))
        # Horizontal splits
        if placed_rect.y < free_rect.y + free_rect.height and placed_rect.y + placed_rect.height > free_rect.y:
            # Left
            if placed_rect.x > free_rect.x:
                new_rects.append(Rect(
                    free_rect.x,
                    free_rect.y,
                    placed_rect.x - free_rect.x,
                    free_rect.height
                ))
            # Right
            if placed_rect.x + placed_rect.width < free_rect.x + free_rect.width:
                new_rects.append(Rect(
                    placed_rect.x + placed_rect.width,
                    free_rect.y,
                    (free_rect.x + free_rect.width) - (placed_rect.x + placed_rect.width),
                    free_rect.height
                ))
        return new_rects

    def prune_free_rectangles(self):
        i = 0
        while i < len(self.free_rectangles):
            a = self.free_rectangles[i]
            j = i + 1
            removed_a = False
            while j < len(self.free_rectangles):
                b = self.free_rectangles[j]
                # A inside B
                if (a.x >= b.x and a.y >= b.y and
                    a.x + a.width <= b.x + b.width and
                    a.y + a.height <= b.y + b.height):
                    del self.free_rectangles[i]
                    removed_a = True
                    break
                # B inside A
                if (b.x >= a.x and b.y >= a.y and
                    b.x + b.width <= a.x + a.width and
                    b.y + b.height <= a.y + a.height):
                    del self.free_rectangles[j]
                    j -= 1
                j += 1
            if not removed_a:
                i += 1

    def place(self, width, height, obj):
        node = self.find_position(width, height)
        if not node:
            return None
        node.obj = obj
        self.used_rectangles.append(node)
        updated = []
        for free in self.free_rectangles:
            if not (node.x >= free.x + free.width or
                    node.x + node.width <= free.x or
                    node.y >= free.y + free.height or
                    node.y + node.height <= free.y):
                updated.extend(self.split_free_rect(free, node))
            else:
                updated.append(free)
        self.free_rectangles = updated
        self.prune_free_rectangles()
        return node


# ------------------------------------------------------------
# COLOR GROUPING
# ------------------------------------------------------------


def get_object_color(obj, attribute_name):
    mesh = obj.data
    #attribute_name = "Color"
    # Ensure the attribute exists
    if attribute_name not in mesh.color_attributes:
        return None
    attr = mesh.color_attributes[attribute_name]
    # Ensure it has at least one element
    if len(attr.data) == 0:
        return None
    col = attr.data[0].color
    return (col[0], col[1], col[2])


def color_similarity(c1, c2):
    dist = ((c1[0] - c2[0])**2 +
            (c1[1] - c2[1])**2 +
            (c1[2] - c2[2])**2) ** 0.5
    return 1.0 - (dist / (3 ** 0.5))


def group_objects_by_color(objects, attribute_name, threshold):
    groups = []
    for obj in objects:
        obj_color = get_object_color(obj, attribute_name)
        if obj_color is None:
            obj_color = ("ungrouped",)
        #print(f"{obj.name} color is {obj_color}")
        placed = False
        for group in groups:
            group_color = group["color"]
            if group_color == ("ungrouped",) and obj_color == ("ungrouped",):
                group["objects"].append(obj)
                #print(f"Color Group {groups[-1]} added using object: {obj}")
                placed = True
                break
            if group_color != ("ungrouped",) and obj_color != ("ungrouped",):
                if color_similarity(obj_color, group_color) >= threshold:
                    group["objects"].append(obj)
                    #print(f"Color Group {groups[-1]} added using object: {obj}")
                    placed = True
                    break
        if not placed:
            groups.append({"color": obj_color, "objects": [obj]})
            #print(f"Color Group {groups[-1]} added using object: {obj}")
    return groups


# ------------------------------------------------------------
# PACK A SINGLE GROUP
# ------------------------------------------------------------


def pack_group(objects, inner_width, inner_height, object_padding):
    rects = []
    for obj in objects:
        w, h = get_world_bbox_size(obj)
        rects.append((w, h, obj))
    rects.sort(key=lambda r: r[0] * r[1], reverse=True)
    packer = MaxRectsBin(inner_width, inner_height)
    placements = []
    for w, h, obj in rects:
        placed = packer.place(w + object_padding, h + object_padding, obj)
        if placed:
            placements.append(placed)
    if not placements:
        return [], 0, 0
    group_w = max(r.x + r.width for r in placements)
    group_h = max(r.y + r.height for r in placements)
    return placements, group_w, group_h


# ------------------------------------------------------------
# LAYOUT GROUPS ACROSS MULTIPLE BEDS
# ------------------------------------------------------------


def layout_groups(groups, bed_width, bed_height,
                  edge_padding, group_spacing_x, group_spacing_y, object_padding):
    inner_w = bed_width - 2 * edge_padding
    inner_h = bed_height - 2 * edge_padding
    packed_groups = []
    # First pack each group independently
    for group in groups:
        placements, gw, gh = pack_group(
            group["objects"], inner_w, inner_h, object_padding
        )
        packed_groups.append({"placements": placements, "width": gw, "height": gh})
    # Now place groups into beds
    bed_index = 0
    origin_x = bed_index * bed_width - bed_width / 2
    origin_y = -bed_height / 2
    current_x = origin_x + edge_padding
    current_y = origin_y + edge_padding
    row_max_height = 0
    for group in packed_groups:
        gw = group["width"]
        gh = group["height"]
        # Wrap to next row
        if current_x + gw > origin_x + bed_width - edge_padding:
            current_x = origin_x + edge_padding
            current_y += row_max_height + group_spacing_y
            row_max_height = 0
        # Move to next bed
        if current_y + gh > origin_y + bed_height - edge_padding:
            bed_index += 1
            origin_x = bed_index * bed_width - bed_width / 2
            origin_y = -bed_height / 2
            current_x = origin_x + edge_padding
            current_y = origin_y + edge_padding
            row_max_height = 0
        # Place objects
        for rect in group["placements"]:
            obj = rect.obj
            obj.location.x = current_x + rect.x + rect.width / 2
            obj.location.y = current_y + rect.y + rect.height / 2
        current_x += gw + group_spacing_x
        row_max_height = max(row_max_height, gh)


#End CoPilot help, back to Serpens


def sna_uifn_print_prep_main_C1D86(layout_function, ):
    layout_function.separator(factor=1.0)
    layout_function.label(text='Cutter Operation', icon_value=0)
    if bpy.context.view_layer.objects.selected:
        if (len(list(bpy.context.view_layer.objects.selected)) > 1):
            if bpy.context.view_layer.objects.active:
                if bpy.context.view_layer.objects.active.select_get():
                    layout_function = layout_function
                    sna_uifn_use_active_to_cut_selected_8DD22(layout_function, True)
                else:
                    layout_function = layout_function
                    sna_uifn_use_active_to_cut_selected_8DD22(layout_function, False)
            else:
                layout_function = layout_function
                sna_uifn_use_active_to_cut_selected_8DD22(layout_function, False)
        else:
            layout_function = layout_function
            sna_uifn_use_active_to_cut_selected_8DD22(layout_function, False)
    else:
        layout_function = layout_function
        sna_uifn_use_active_to_cut_selected_8DD22(layout_function, False)


def sna_uifn_use_active_to_cut_selected_8DD22(layout_function, enabled):
    row_642EA = layout_function.row(heading='', align=False)
    row_642EA.alert = False
    row_642EA.enabled = enabled
    row_642EA.active = True
    row_642EA.use_property_split = False
    row_642EA.use_property_decorate = False
    row_642EA.scale_x = 1.0
    row_642EA.scale_y = 2.0
    row_642EA.alignment = 'Expand'.upper()
    row_642EA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = row_642EA.operator('sna.use_active_to_cut_selected_b4720', text='Duplicate Active + Cut Selected', icon_value=0, emboss=True, depress=False)


class SNA_PT_PRINT_PREP_FEEEC(bpy.types.Panel):
    bl_label = 'Print Prep'
    bl_idname = 'SNA_PT_PRINT_PREP_FEEEC'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = '3D Print'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_uifn_print_prep_main_C1D86(layout_function, )


def sna_uifn_active_and_selected_objects_ED8AF(layout_function, ):
    col_D273C = layout_function.column(heading='', align=True)
    col_D273C.alert = False
    col_D273C.enabled = True
    col_D273C.active = True
    col_D273C.use_property_split = True
    col_D273C.use_property_decorate = False
    col_D273C.scale_x = 1.0
    col_D273C.scale_y = 1.0
    col_D273C.alignment = 'Expand'.upper()
    col_D273C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_D273C.label(text='Active Object', icon_value=0)
    row_033D5 = col_D273C.row(heading='', align=True)
    row_033D5.alert = False
    row_033D5.enabled = True
    row_033D5.active = True
    row_033D5.use_property_split = True
    row_033D5.use_property_decorate = False
    row_033D5.scale_x = 1.0
    row_033D5.scale_y = 1.0
    row_033D5.alignment = 'Left'.upper()
    row_033D5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    if bpy.context.view_layer.objects.active:
        if bpy.context.view_layer.objects.active.select_get():
            row_033D5.label(text=bpy.context.view_layer.objects.active.name, icon_value=string_to_icon('DOT'))
        else:
            row_033D5.label(text='Active Object is not selected', icon_value=string_to_icon('DOT'))
    else:
        row_033D5.label(text='No Active Object', icon_value=string_to_icon('DOT'))
    col_D273C.separator(factor=1.0)
    if bpy.context.view_layer.objects.selected:
        if (len(list(bpy.context.view_layer.objects.selected)) > 1):
            col_D273C.label(text='Selected Objects', icon_value=0)
            for i_07A85 in range(len(bpy.context.view_layer.objects.selected)-1,-1,-1):
                if (bpy.context.view_layer.objects.selected[i_07A85] != bpy.context.view_layer.objects.active):
                    row_1EC11 = col_D273C.row(heading='', align=True)
                    row_1EC11.alert = False
                    row_1EC11.enabled = True
                    row_1EC11.active = True
                    row_1EC11.use_property_split = False
                    row_1EC11.use_property_decorate = False
                    row_1EC11.scale_x = 1.0
                    row_1EC11.scale_y = 1.0
                    row_1EC11.alignment = 'Expand'.upper()
                    row_1EC11.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    row_1EC11.label(text=bpy.context.view_layer.objects.selected[i_07A85].name, icon_value=string_to_icon('DOT'))
                    op = row_1EC11.operator('sna.activate_object_81920', text='', icon_value=string_to_icon('RESTRICT_SELECT_OFF'), emboss=False, depress=False)
                    op.sna_selected_object = bpy.context.view_layer.objects.selected[i_07A85].name
                    op = row_1EC11.operator('sna.deselect_object_dbfbd', text='', icon_value=string_to_icon('PANEL_CLOSE'), emboss=False, depress=False)
                    op.sna_selected_object = bpy.context.view_layer.objects.selected[i_07A85].name


def sna_uifn_active_cutter_object_8F631(layout_function, ):
    if bpy.context.view_layer.objects.active:
        if bpy.context.view_layer.objects.active.select_get():
            col_7CEC6 = layout_function.column(heading='', align=True)
            col_7CEC6.alert = False
            col_7CEC6.enabled = bpy.context.preferences.addons[__package__].preferences.sna_cutter_suffix in bpy.context.view_layer.objects.active.name
            col_7CEC6.active = True
            col_7CEC6.use_property_split = True
            col_7CEC6.use_property_decorate = False
            col_7CEC6.scale_x = 1.0
            col_7CEC6.scale_y = 1.0
            col_7CEC6.alignment = 'Expand'.upper()
            col_7CEC6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_7CEC6.operator('sna.select_affected_objects_of_cutter_231cd', text='Select Affected Objects', icon_value=string_to_icon('RESTRICT_SELECT_OFF'), emboss=True, depress=False)
            op.sna_cutter_object = bpy.context.view_layer.objects.active.name
            op = col_7CEC6.operator('sna.delete_and_remove_cutter_from_all_affected_objects_b38b1', text='Delete and Remove Cutter', icon_value=string_to_icon('TRASH'), emboss=True, depress=False)
            op.sna_cutter_object = bpy.context.view_layer.objects.active.name
            col_7CEC6.separator(factor=3.0)
            row_15366 = col_7CEC6.row(heading='', align=True)
            row_15366.alert = False
            row_15366.enabled = True
            row_15366.active = True
            row_15366.use_property_split = True
            row_15366.use_property_decorate = False
            row_15366.scale_x = 1.0
            row_15366.scale_y = 1.0
            row_15366.alignment = 'Expand'.upper()
            row_15366.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_15366.label(text='Objects cut by ' + bpy.context.view_layer.objects.active.name + ':', icon_value=0)
            op = row_15366.operator('sna.update_cutter_affected_objects_collection_edbc7', text='', icon_value=string_to_icon('FILE_REFRESH'), emboss=False, depress=False)
            op.sna_cutter_object = bpy.context.view_layer.objects.active.name
            box_02C3F = col_7CEC6.box()
            box_02C3F.alert = False
            box_02C3F.enabled = True
            box_02C3F.active = True
            box_02C3F.use_property_split = True
            box_02C3F.use_property_decorate = False
            box_02C3F.alignment = 'Expand'.upper()
            box_02C3F.scale_x = 1.0
            box_02C3F.scale_y = 1.0
            if not True: box_02C3F.operator_context = "EXEC_DEFAULT"
            for i_06C0B in range(len(bpy.context.view_layer.objects.active.sna_affected_objects_collection)-1,-1,-1):
                col_7BCE8 = box_02C3F.column(heading='', align=True)
                col_7BCE8.alert = False
                col_7BCE8.enabled = True
                col_7BCE8.active = True
                col_7BCE8.use_property_split = True
                col_7BCE8.use_property_decorate = False
                col_7BCE8.scale_x = 1.0
                col_7BCE8.scale_y = 1.0
                col_7BCE8.alignment = 'Expand'.upper()
                col_7BCE8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_5561B = col_7BCE8.row(heading='', align=True)
                row_5561B.alert = False
                row_5561B.enabled = True
                row_5561B.active = True
                row_5561B.use_property_split = True
                row_5561B.use_property_decorate = False
                row_5561B.scale_x = 1.0
                row_5561B.scale_y = 1.0
                row_5561B.alignment = 'Left'.upper()
                row_5561B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_5561B.label(text=bpy.context.view_layer.objects.active.sna_affected_objects_collection[i_06C0B].affected_object, icon_value=string_to_icon('DOT'))
                op = row_5561B.operator('sna.select_affected_object_3e0d0', text='', icon_value=string_to_icon('RESTRICT_SELECT_OFF'), emboss=True, depress=False)
                op.sna_object = bpy.context.view_layer.objects.active.sna_affected_objects_collection[i_06C0B].affected_object
                op = row_5561B.operator('sna.remove_cutter_66191', text='', icon_value=string_to_icon('PANEL_CLOSE'), emboss=True, depress=False)
                op.sna_cutter_object = bpy.context.view_layer.objects.active.sna_affected_objects_collection[i_06C0B].cutter_object
                op.sna_affected_object = bpy.context.view_layer.objects.active.sna_affected_objects_collection[i_06C0B].affected_object


def sna_uifn_cutter_mods_on_active_94596(layout_function, ):
    col_FB1A4 = layout_function.column(heading='', align=True)
    col_FB1A4.alert = False
    col_FB1A4.enabled = True
    col_FB1A4.active = True
    col_FB1A4.use_property_split = True
    col_FB1A4.use_property_decorate = False
    col_FB1A4.scale_x = 1.0
    col_FB1A4.scale_y = 1.0
    col_FB1A4.alignment = 'Expand'.upper()
    col_FB1A4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    if bpy.context.view_layer.objects.active:
        if bpy.context.view_layer.objects.active.select_get():
            col_FB1A4.label(text='Objects cutting ' + bpy.context.view_layer.objects.active.name + ':', icon_value=0)
            for i_E81B3 in range(len(bpy.context.view_layer.objects.active.modifiers)-1,-1,-1):
                if (bpy.context.view_layer.objects.active.modifiers[i_E81B3].type == 'BOOLEAN'):
                    if bpy.context.view_layer.objects.active.modifiers[i_E81B3].object:
                        row_DAD81 = col_FB1A4.row(heading='', align=True)
                        row_DAD81.alert = False
                        row_DAD81.enabled = True
                        row_DAD81.active = True
                        row_DAD81.use_property_split = True
                        row_DAD81.use_property_decorate = False
                        row_DAD81.scale_x = 1.0
                        row_DAD81.scale_y = 1.0
                        row_DAD81.alignment = 'Left'.upper()
                        row_DAD81.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                        row_DAD81.label(text=bpy.context.view_layer.objects.active.modifiers[i_E81B3].object.name, icon_value=string_to_icon('DOT'))
                        row_DAD81.prop(bpy.context.view_layer.objects.active.modifiers[i_E81B3].object, 'hide_select', text='', icon_value=0, emboss=False)
                        row_DAD81.prop(bpy.context.view_layer.objects.active.modifiers[i_E81B3].object, 'sna_toggle_show_hide', text='', icon_value=(string_to_icon('HIDE_ON') if bpy.context.view_layer.objects.active.modifiers[i_E81B3].object.hide_get() else string_to_icon('HIDE_OFF')), emboss=False)
                        row_DAD81.prop(bpy.context.view_layer.objects.active.modifiers[i_E81B3].object, 'hide_viewport', text='', icon_value=0, emboss=False)
                        row_DAD81.prop(bpy.context.view_layer.objects.active.modifiers[i_E81B3].object, 'hide_render', text='', icon_value=0, emboss=False)
                        row_DAD81.separator(factor=2.0)
                        op = row_DAD81.operator('sna.select_cutter_object_d9844', text='', icon_value=string_to_icon('RESTRICT_SELECT_OFF'), emboss=True, depress=False)
                        op.sna_object = bpy.context.view_layer.objects.active.modifiers[i_E81B3].object.name
                        op = row_DAD81.operator('sna.remove_cutter_66191', text='', icon_value=string_to_icon('PANEL_CLOSE'), emboss=True, depress=False)
                        op.sna_cutter_object = bpy.context.view_layer.objects.active.modifiers[i_E81B3].object.name
                        op.sna_affected_object = bpy.context.view_layer.objects.active.name


def sna_uifn_cutter_settings_80CD9(layout_function, ):
    col_70977 = layout_function.column(heading='', align=True)
    col_70977.alert = False
    col_70977.enabled = True
    col_70977.active = True
    col_70977.use_property_split = True
    col_70977.use_property_decorate = False
    col_70977.scale_x = 1.0
    col_70977.scale_y = 1.0
    col_70977.alignment = 'Expand'.upper()
    col_70977.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_70977.label(text='Use Active Object to Cut Selected Objects (with gap)', icon_value=0)
    col_70977.separator(factor=3.0)
    col_70977.label(text='Cutter Settings', icon_value=0)
    row_A34E3 = col_70977.row(heading='', align=True)
    row_A34E3.alert = False
    row_A34E3.enabled = True
    row_A34E3.active = True
    row_A34E3.use_property_split = True
    row_A34E3.use_property_decorate = False
    row_A34E3.scale_x = 1.0
    row_A34E3.scale_y = 1.0
    row_A34E3.alignment = 'Expand'.upper()
    row_A34E3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_A34E3.prop(bpy.context.scene, 'sna_gap_direction', text='Cut Direction', icon_value=0, emboss=True, expand=True)
    col_70977.prop(bpy.context.scene, 'sna_cutter_gap', text='Gap', icon_value=0, emboss=True)
    col_70977.prop(bpy.context.scene, 'sna_even_thickness', text='Even Thickness', icon_value=0, emboss=True, toggle=True)
    col_70977.prop(bpy.context.scene, 'sna_cut_from_outside_only_rim', text='Cut Gap with Rim Only', icon_value=0, emboss=True, toggle=True)
    row_7064D = col_70977.row(heading='', align=True)
    row_7064D.alert = False
    row_7064D.enabled = True
    row_7064D.active = True
    row_7064D.use_property_split = True
    row_7064D.use_property_decorate = False
    row_7064D.scale_x = 1.0
    row_7064D.scale_y = 1.0
    row_7064D.alignment = 'Expand'.upper()
    row_7064D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_7064D.prop(bpy.context.scene, 'sna_boolean_solver', text='Bool Solver', icon_value=0, emboss=True, expand=True)
    row_1D221 = col_70977.row(heading='', align=True)
    row_1D221.alert = False
    row_1D221.enabled = True
    row_1D221.active = True
    row_1D221.use_property_split = True
    row_1D221.use_property_decorate = False
    row_1D221.scale_x = 1.0
    row_1D221.scale_y = 1.0
    row_1D221.alignment = 'Expand'.upper()
    row_1D221.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_1D221.prop(bpy.context.scene, 'sna_transfer_material', text='Materials', icon_value=0, emboss=True, expand=True)
    col_70977.separator(factor=3.0)
    col_70977.label(text='Cutter Visibility', icon_value=0)
    col_70977.prop(bpy.context.scene, 'sna_hide_from_viewport', text='Hide from Viewport', icon_value=0, emboss=True, toggle=True)
    col_70977.prop(bpy.context.scene, 'sna_hide_from_render', text='Hide from Render', icon_value=0, emboss=True, toggle=True)
    col_70977.separator(factor=3.0)
    col_70977.label(text='Cutter Material', icon_value=0)
    col_70977.prop(bpy.context.scene, 'sna_add_material_to_cutter', text='Add Material to Cutter', icon_value=0, emboss=True, toggle=True)
    col_70977.prop(bpy.context.scene, 'sna_material_color', text='Material Color', icon_value=0, emboss=True)
    col_70977.separator(factor=3.0)
    col_70977.label(text='Cutter Suffix', icon_value=0)
    col_70977.prop(bpy.context.preferences.addons[__package__].preferences, 'sna_cutter_suffix', text='Add to Name', icon_value=0, emboss=True)


def sna_uifn_material_settings_748C6(layout_function, ):
    col_CCE0D = layout_function.column(heading='', align=True)
    col_CCE0D.alert = False
    col_CCE0D.enabled = True
    col_CCE0D.active = True
    col_CCE0D.use_property_split = True
    col_CCE0D.use_property_decorate = False
    col_CCE0D.scale_x = 1.0
    col_CCE0D.scale_y = 1.0
    col_CCE0D.alignment = 'Expand'.upper()
    col_CCE0D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    if bpy.context.view_layer.objects.active:
        if bpy.context.view_layer.objects.active.visible_get():
            if bpy.context.view_layer.objects.active.type == 'MESH':
                if 'PAINT_VERTEX'==bpy.context.mode:
                    col_CCE0D.label(text='Vertex Paint Color Palette', icon_value=0)
                else:
                    col_CCE0D.label(text='Requires Active Object + Vertex Paint Mode', icon_value=0)
            else:
                col_CCE0D.label(text='Requires Active Object + Vertex Paint Mode', icon_value=0)
        else:
            col_CCE0D.label(text='Requires Active Object + Vertex Paint Mode', icon_value=0)
    else:
        col_CCE0D.label(text='Requires Active Object + Vertex Paint Mode', icon_value=0)
    if bpy.context.view_layer.objects.active:
        if bpy.context.view_layer.objects.active.visible_get():
            if bpy.context.view_layer.objects.active.type == 'MESH':
                if 'PAINT_VERTEX'==bpy.context.mode:
                    op = col_CCE0D.operator('object.mode_set', text='Go to Object Mode', icon_value=string_to_icon('OBJECT_DATAMODE'), emboss=True, depress=False)
                    op.mode = 'OBJECT'
                else:
                    op = col_CCE0D.operator('object.mode_set', text='Go to Vertex Paint Mode', icon_value=string_to_icon('VPAINT_HLT'), emboss=True, depress=False)
                    op.mode = 'VERTEX_PAINT'
            else:
                col_89C86 = col_CCE0D.column(heading='', align=True)
                col_89C86.alert = False
                col_89C86.enabled = False
                col_89C86.active = True
                col_89C86.use_property_split = True
                col_89C86.use_property_decorate = False
                col_89C86.scale_x = 1.0
                col_89C86.scale_y = 1.0
                col_89C86.alignment = 'Expand'.upper()
                col_89C86.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = col_89C86.operator('object.mode_set', text='Go to Vertex Paint Mode', icon_value=string_to_icon('VPAINT_HLT'), emboss=True, depress=False)
        else:
            col_C1390 = col_CCE0D.column(heading='', align=True)
            col_C1390.alert = False
            col_C1390.enabled = False
            col_C1390.active = True
            col_C1390.use_property_split = True
            col_C1390.use_property_decorate = False
            col_C1390.scale_x = 1.0
            col_C1390.scale_y = 1.0
            col_C1390.alignment = 'Expand'.upper()
            col_C1390.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_C1390.operator('object.mode_set', text='Go to Vertex Paint Mode', icon_value=string_to_icon('VPAINT_HLT'), emboss=True, depress=False)
    else:
        col_B0389 = col_CCE0D.column(heading='', align=True)
        col_B0389.alert = False
        col_B0389.enabled = False
        col_B0389.active = True
        col_B0389.use_property_split = True
        col_B0389.use_property_decorate = False
        col_B0389.scale_x = 1.0
        col_B0389.scale_y = 1.0
        col_B0389.alignment = 'Expand'.upper()
        col_B0389.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_B0389.operator('object.mode_set', text='Go to Vertex Paint Mode', icon_value=string_to_icon('VPAINT_HLT'), emboss=True, depress=False)
    op = col_CCE0D.operator('sna.add_or_update_fdm_material_37519', text='Add or Update FDM Material', icon_value=string_to_icon('MATERIAL'), emboss=True, depress=False)
    op.sna_custom_color = bpy.context.scene.tool_settings.vertex_paint.unified_paint_settings.color
    if bpy.context.view_layer.objects.active:
        if bpy.context.view_layer.objects.active.visible_get():
            if bpy.context.view_layer.objects.active.type == 'MESH':
                col_342C6 = col_CCE0D.column(heading='', align=True)
                col_342C6.alert = False
                col_342C6.enabled = 'PAINT_VERTEX'==bpy.context.mode
                col_342C6.active = True
                col_342C6.use_property_split = True
                col_342C6.use_property_decorate = False
                col_342C6.scale_x = 1.0
                col_342C6.scale_y = 1.0
                col_342C6.alignment = 'Expand'.upper()
                col_342C6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                exec('col_342C6.template_ID(bpy.context.scene, "sna_palette_prop", new="palette.new")')
            else:
                col_30696 = col_CCE0D.column(heading='', align=True)
                col_30696.alert = False
                col_30696.enabled = False
                col_30696.active = True
                col_30696.use_property_split = True
                col_30696.use_property_decorate = False
                col_30696.scale_x = 1.0
                col_30696.scale_y = 1.0
                col_30696.alignment = 'Expand'.upper()
                col_30696.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                exec('col_30696.template_ID(bpy.context.scene, "sna_palette_prop", new="palette.new")')
        else:
            col_50C7E = col_CCE0D.column(heading='', align=True)
            col_50C7E.alert = False
            col_50C7E.enabled = False
            col_50C7E.active = True
            col_50C7E.use_property_split = True
            col_50C7E.use_property_decorate = False
            col_50C7E.scale_x = 1.0
            col_50C7E.scale_y = 1.0
            col_50C7E.alignment = 'Expand'.upper()
            col_50C7E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            exec('col_50C7E.template_ID(bpy.context.scene, "sna_palette_prop", new="palette.new")')
    else:
        col_0DE30 = col_CCE0D.column(heading='', align=True)
        col_0DE30.alert = False
        col_0DE30.enabled = False
        col_0DE30.active = True
        col_0DE30.use_property_split = True
        col_0DE30.use_property_decorate = False
        col_0DE30.scale_x = 1.0
        col_0DE30.scale_y = 1.0
        col_0DE30.alignment = 'Expand'.upper()
        col_0DE30.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        exec('col_0DE30.template_ID(bpy.context.scene, "sna_palette_prop", new="palette.new")')
    col_25577 = col_CCE0D.column(heading='', align=True)
    col_25577.alert = False
    col_25577.enabled = True
    col_25577.active = True
    col_25577.use_property_split = True
    col_25577.use_property_decorate = False
    col_25577.scale_x = 1.0
    col_25577.scale_y = 1.0
    col_25577.alignment = 'Expand'.upper()
    col_25577.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_25577.prop(bpy.context.scene.tool_settings.vertex_paint.unified_paint_settings, 'color', text='', icon_value=0, emboss=True)
    if bpy.context.scene.sna_palette_prop:
        col_03798 = col_25577.column(heading='', align=True)
        col_03798.alert = False
        col_03798.enabled = True
        col_03798.active = True
        col_03798.use_property_split = True
        col_03798.use_property_decorate = False
        col_03798.scale_x = 1.0
        col_03798.scale_y = 1.0
        col_03798.alignment = 'Expand'.upper()
        col_03798.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        exec('col_03798.template_palette(bpy.context.scene, "sna_palette_prop", color=True)')


def sna_uifn_object_placement_707E1(layout_function, ):
    col_F6062 = layout_function.column(heading='', align=True)
    col_F6062.alert = False
    col_F6062.enabled = True
    col_F6062.active = True
    col_F6062.use_property_split = True
    col_F6062.use_property_decorate = False
    col_F6062.scale_x = 1.0
    col_F6062.scale_y = 1.0
    col_F6062.alignment = 'Expand'.upper()
    col_F6062.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    if 'OBJECT'==bpy.context.mode:
        pass
    else:
        col_F6062.label(text='Requires Object Mode (Affects Origins)', icon_value=0)
    row_22EE2 = col_F6062.row(heading='', align=True)
    row_22EE2.alert = False
    row_22EE2.enabled = True
    row_22EE2.active = True
    row_22EE2.use_property_split = True
    row_22EE2.use_property_decorate = False
    row_22EE2.scale_x = 1.0
    row_22EE2.scale_y = 1.0
    row_22EE2.alignment = 'Expand'.upper()
    row_22EE2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_22EE2.prop(bpy.context.scene, 'sna_activate_face_align', text='Face Align (Origins)', icon_value=string_to_icon('SNAP_FACE_CENTER'), emboss=True, toggle=True)
    col_F6062.prop(bpy.context.scene, 'sna_use_keyframes', text='Use Keyframes', icon_value=string_to_icon('DECORATE_KEYFRAME'), emboss=True, toggle=True)
    col_C73C4 = col_F6062.column(heading='', align=True)
    col_C73C4.alert = False
    col_C73C4.enabled = True
    col_C73C4.active = bpy.context.scene.sna_use_keyframes
    col_C73C4.use_property_split = True
    col_C73C4.use_property_decorate = False
    col_C73C4.scale_x = 1.0
    col_C73C4.scale_y = 1.0
    col_C73C4.alignment = 'Expand'.upper()
    col_C73C4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_C73C4.prop(bpy.context.scene, 'sna_print_prep_start_frame', text='Start Frame', icon_value=0, emboss=True)
    col_C73C4.prop(bpy.context.scene, 'sna_print_prep_end_frame', text='End Frame', icon_value=0, emboss=True)
    col_F6062.separator(factor=3.0)
    row_44DCD = col_F6062.row(heading='', align=True)
    row_44DCD.alert = False
    row_44DCD.enabled = True
    row_44DCD.active = True
    row_44DCD.use_property_split = True
    row_44DCD.use_property_decorate = False
    row_44DCD.scale_x = 1.0
    row_44DCD.scale_y = 1.0
    row_44DCD.alignment = 'Expand'.upper()
    row_44DCD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_44DCD.label(text='', icon_value=(string_to_icon('DECORATE_KEYFRAME') if bpy.context.scene.sna_use_keyframes else string_to_icon('BLANK1')))
    op = row_44DCD.operator('sna.move_to_world_origin_and_clear_rotation_f7f82', text='Move to Print Bed (Origin)', icon_value=string_to_icon('OBJECT_ORIGIN'), emboss=True, depress=False)
    col_F6062.separator(factor=3.0)
    row_4C93A = col_F6062.row(heading='', align=True)
    row_4C93A.alert = False
    row_4C93A.enabled = True
    row_4C93A.active = True
    row_4C93A.use_property_split = True
    row_4C93A.use_property_decorate = False
    row_4C93A.scale_x = 1.0
    row_4C93A.scale_y = 1.0
    row_4C93A.alignment = 'Expand'.upper()
    row_4C93A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_4C93A.label(text='', icon_value=string_to_icon('BLANK1'))
    op = row_4C93A.operator('object.randomize_transform', text='Randomize Transform', icon_value=0, emboss=True, depress=False)
    op.use_delta = False
    op.use_loc = True
    op.loc = (bpy.context.scene.sna_random_transform_x, bpy.context.scene.sna_random_transform_y, 0.0)
    op.use_rot = False
    op.use_scale = False
    op.scale_even = False
    col_F6062.prop(bpy.context.scene, 'sna_random_transform_x', text='Random X', icon_value=0, emboss=True)
    col_F6062.prop(bpy.context.scene, 'sna_random_transform_y', text='Random Y', icon_value=0, emboss=True)
    col_F6062.separator(factor=3.0)
    row_F3704 = col_F6062.row(heading='', align=True)
    row_F3704.alert = False
    row_F3704.enabled = True
    row_F3704.active = True
    row_F3704.use_property_split = True
    row_F3704.use_property_decorate = False
    row_F3704.scale_x = 1.0
    row_F3704.scale_y = 1.0
    row_F3704.alignment = 'Expand'.upper()
    row_F3704.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_F3704.label(text='', icon_value=(string_to_icon('DECORATE_KEYFRAME') if bpy.context.scene.sna_use_keyframes else string_to_icon('BLANK1')))
    op = row_F3704.operator('sna.smart_pack_beds_b19df', text='Pack Selected on Print Bed (Experimental)', icon_value=string_to_icon('CON_GEOMETRYATTRIBUTE'), emboss=True, depress=False)
    op.sna_object_spacing = bpy.context.scene.sna_smart_pack_object_spacing
    op.sna_group_spacing = bpy.context.scene.sna_smart_pack_group_spacing
    op.sna_bed_edge_spacing = bpy.context.scene.sna_smart_pack_bed_spacing
    op.sna_bed_length_x = bpy.context.scene.sna_smart_pack_bed_length_x
    op.sna_bed_length_y = bpy.context.scene.sna_smart_pack_bed_length_y
    op.sna_color_match = bpy.context.scene.sna_color_match
    col_F6062.prop(bpy.context.scene, 'sna_smart_pack_object_spacing', text='Object Spacing', icon_value=0, emboss=True)
    col_F6062.prop(bpy.context.scene, 'sna_smart_pack_group_spacing', text='Group Spacing', icon_value=0, emboss=True)
    col_F6062.prop(bpy.context.scene, 'sna_smart_pack_bed_spacing', text='Bed Edge Spacing', icon_value=0, emboss=True)
    col_F6062.prop(bpy.context.scene, 'sna_smart_pack_bed_length_x', text='Print Bed X', icon_value=0, emboss=True)
    col_F6062.prop(bpy.context.scene, 'sna_smart_pack_bed_length_y', text='Print Bed Y', icon_value=0, emboss=True)
    col_F6062.prop(bpy.context.scene, 'sna_color_match', text='Color Match', icon_value=0, emboss=True)


def sna_uifn_printer_proxy_111FA(layout_function, ):
    col_57688 = layout_function.column(heading='', align=True)
    col_57688.alert = False
    col_57688.enabled = True
    col_57688.active = True
    col_57688.use_property_split = True
    col_57688.use_property_decorate = False
    col_57688.scale_x = 1.0
    col_57688.scale_y = 1.0
    col_57688.alignment = 'Expand'.upper()
    col_57688.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = col_57688.operator('sna.append_printer_proxy_160ed', text='Append Printer Proxy', icon_value=string_to_icon('COLLECTION_NEW'), emboss=True, depress=False)
    op = col_57688.operator('sna.set_units_and_3d_view_clipping_be2d0', text='Set Units and 3D View Clipping', icon_value=string_to_icon('SCENE_DATA'), emboss=True, depress=False)
    col_57688.prop(bpy.context.scene.unit_settings, 'system', text='Unit System', icon_value=0, emboss=True)
    col_57688.prop(bpy.context.scene.unit_settings, 'scale_length', text='Unit Scale', icon_value=0, emboss=True)
    col_57688.prop(bpy.context.scene.unit_settings, 'length_unit', text='Length', icon_value=0, emboss=True)
    col_57688.prop(find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces[0], 'clip_start', text='Clip Start', icon_value=0, emboss=True)
    col_57688.prop(find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces[0], 'clip_end', text='Clip End', icon_value=0, emboss=True)
    col_57688.separator(factor=3.0)
    col_57688.prop(bpy.context.scene, 'camera', text='Scene Camera', icon_value=0, emboss=True)
    if bpy.context.scene.camera:
        col_57688.prop(bpy.context.scene.camera.data, 'clip_start', text='Clip Start', icon_value=0, emboss=True)
        col_57688.prop(bpy.context.scene.camera.data, 'clip_end', text='Clip Start', icon_value=0, emboss=True)
    else:
        col_57688.label(text='Select a scene camera for clip settings', icon_value=0)


def sna_uifn_tutorials_D2D83(layout_function, ):
    col_19C90 = layout_function.column(heading='', align=True)
    col_19C90.alert = False
    col_19C90.enabled = True
    col_19C90.active = True
    col_19C90.use_property_split = True
    col_19C90.use_property_decorate = False
    col_19C90.scale_x = 1.0
    col_19C90.scale_y = 1.0
    col_19C90.alignment = 'Expand'.upper()
    col_19C90.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_19C90.label(text='List of Tutorials:', icon_value=0)
    op = col_19C90.operator('wm.url_open', text='Tutorials Playlist', icon_value=0, emboss=True, depress=False)
    op.url = 'https://www.youtube.com/playlist?list=PLu2W61Z2aOrXpwRfx3lF2vWdpOi1f242R'
    op = col_19C90.operator('wm.url_open', text='Add Proxy & Demo Character', icon_value=0, emboss=True, depress=False)
    op.url = 'https://youtu.be/-XK25sdlkuY'
    op = col_19C90.operator('wm.url_open', text='Shader, Vertex Paint, and Material Settings', icon_value=0, emboss=True, depress=False)
    op.url = 'https://youtu.be/vFmulT04GSQ'
    op = col_19C90.operator('wm.url_open', text='Cutting and Keying Objects', icon_value=0, emboss=True, depress=False)
    op.url = 'https://youtu.be/VUyMVH0tw0g'
    op = col_19C90.operator('wm.url_open', text='Bed Placement', icon_value=0, emboss=True, depress=False)
    op.url = 'https://youtu.be/JCEng2Rzsqc'


class SNA_PT_OBJECT_SELECTION_724EA(bpy.types.Panel):
    bl_label = 'Object Selection'
    bl_idname = 'SNA_PT_OBJECT_SELECTION_724EA'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_PRINT_PREP_FEEEC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_uifn_active_and_selected_objects_ED8AF(layout_function, )


class SNA_PT_CUT_OBJECT_SETTINGS_04712(bpy.types.Panel):
    bl_label = 'Cut Object Settings'
    bl_idname = 'SNA_PT_CUT_OBJECT_SETTINGS_04712'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_PRINT_PREP_FEEEC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_uifn_cutter_mods_on_active_94596(layout_function, )


class SNA_PT_CUTTER_OBJECT_SETTINGS_FD083(bpy.types.Panel):
    bl_label = 'Cutter Object Settings'
    bl_idname = 'SNA_PT_CUTTER_OBJECT_SETTINGS_FD083'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 3
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_PRINT_PREP_FEEEC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_uifn_active_cutter_object_8F631(layout_function, )


class SNA_PT_SETUP_FOR_CUTTING_47B16(bpy.types.Panel):
    bl_label = 'Setup for Cutting'
    bl_idname = 'SNA_PT_SETUP_FOR_CUTTING_47B16'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_PRINT_PREP_FEEEC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_uifn_cutter_settings_80CD9(layout_function, )


class SNA_PT_OBJECT_PLACEMENT_DF668(bpy.types.Panel):
    bl_label = 'Object Placement'
    bl_idname = 'SNA_PT_OBJECT_PLACEMENT_DF668'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 4
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_PRINT_PREP_FEEEC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.prop(bpy.context.scene, 'sna_activate_face_align', text='', icon_value=string_to_icon('SNAP_FACE_CENTER'), emboss=True)

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_uifn_object_placement_707E1(layout_function, )


class SNA_PT_PRINTER_PROXY_47636(bpy.types.Panel):
    bl_label = 'Printer Proxy'
    bl_idname = 'SNA_PT_PRINTER_PROXY_47636'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 5
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_PRINT_PREP_FEEEC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_uifn_printer_proxy_111FA(layout_function, )


class SNA_PT_MATERIAL_SETTINGS_72DB7(bpy.types.Panel):
    bl_label = 'Material Settings'
    bl_idname = 'SNA_PT_MATERIAL_SETTINGS_72DB7'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 6
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_PRINT_PREP_FEEEC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_uifn_material_settings_748C6(layout_function, )


class SNA_PT_VIDEO_TUTORIALS_B31D7(bpy.types.Panel):
    bl_label = 'Video Tutorials'
    bl_idname = 'SNA_PT_VIDEO_TUTORIALS_B31D7'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 7
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_PRINT_PREP_FEEEC'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_uifn_tutorials_D2D83(layout_function, )


class SNA_GROUP_sna_affected_objects_group(bpy.types.PropertyGroup):
    affected_object: bpy.props.StringProperty(name='Affected Object', description='This object is affected by the cutter object', default='', subtype='NONE', maxlen=0)
    cutter_object: bpy.props.StringProperty(name='Cutter Object', description='The object performing the cutting', default='', subtype='NONE', maxlen=0)


class SNA_AddonPreferences_88A14(bpy.types.AddonPreferences):
    bl_idname = __package__
    sna_cutter_suffix: bpy.props.StringProperty(name='Cutter_Suffix', description='Pick the Suffix for the Cutter (default is ".Bool_Cutter")', default='.Bool_Cutter', subtype='NONE', maxlen=0)

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout.label(text='Found on 3D Viewport', icon_value=0)
            layout.label(text='N-Panel Category: 3D Print', icon_value=0)
            layout.label(text='Panel Name: Print Prep', icon_value=0)
            col_56B40 = layout.column(heading='', align=True)
            col_56B40.alert = False
            col_56B40.enabled = True
            col_56B40.active = True
            col_56B40.use_property_split = True
            col_56B40.use_property_decorate = False
            col_56B40.scale_x = 1.0
            col_56B40.scale_y = 1.0
            col_56B40.alignment = 'Expand'.upper()
            col_56B40.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_56B40.prop(bpy.context.preferences.addons[__package__].preferences, 'sna_cutter_suffix', text='Cutter Suffix', icon_value=0, emboss=True)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_affected_objects_group)
    bpy.types.Scene.sna_cutter_gap = bpy.props.FloatProperty(name='Cutter Gap', description='Amount gap between the cut object and cutter for 3D print', default=0.10000000149011612, subtype='DISTANCE', unit='LENGTH', soft_min=9.999999747378752e-06, step=1, precision=2)
    bpy.types.Scene.sna_gap_direction = bpy.props.EnumProperty(name='Gap Direction', description='Gap direction will either grow or shrink the cutter object', items=[('Grow', 'Grow', 'Offset the gap by growing the cutter object larger', 0, 0), ('Shrink', 'Shrink', 'Offset the gap by shrinking the cutter object larger', 0, 1)])
    bpy.types.Scene.sna_even_thickness = bpy.props.BoolProperty(name='Even Thickness', description='Maintain thickness by adjusting for sharp corners (slow, disable when not needed)', default=True)
    bpy.types.Scene.sna_cut_from_outside_only_rim = bpy.props.BoolProperty(name='Cut from Outside Only (Rim)', description='Cut from the outside surfaces only (recommended)', default=True)
    bpy.types.Scene.sna_boolean_solver = bpy.props.EnumProperty(name='Boolean Solver', description='Solver method for the boolean modifier (manifold is recommended)', items=[('Manifold', 'Manifold', '(Recommended) fastest solver that works only on manifold meshes but gives better results', 0, 0), ('Exact', 'Exact', 'Slower solver with the best results for coplanar faces', 0, 1), ('Float', 'Float', 'Simple solver with good performance without overlapping geometry', 0, 2)])
    bpy.types.Scene.sna_hide_from_viewport = bpy.props.BoolProperty(name='Hide from Viewport', description='Hide the Cutter from the Viewport after being created', default=True)
    bpy.types.Scene.sna_hide_from_render = bpy.props.BoolProperty(name='Hide from Render', description='Hide the Cutter from rendering after being created', default=True)
    bpy.types.Scene.sna_transfer_material = bpy.props.EnumProperty(name='Transfer Material', description='Transfer the material from the cutter', items=[('Transfer', 'Transfer', 'Selects the Material Transfer on the Boolean Solver Option for the cutter', 0, 0), ('Index Based', 'Index Based', 'Selects the Material to Index Based on the Boolean Solver Option for the cutter', 0, 1)])
    bpy.types.Scene.sna_add_material_to_cutter = bpy.props.BoolProperty(name='Add Material to Cutter', description='Make a New Material for the Cutter Object', default=True)
    bpy.types.Scene.sna_material_color = bpy.props.FloatVectorProperty(name='Material Color', description='Color of the Cutter Material', size=4, default=(0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=1, precision=3)
    bpy.types.Object.sna_toggle_show_hide = bpy.props.BoolProperty(name='Toggle Show Hide', description='Toggle visibility of the cutter after creation', default=False, update=sna_update_sna_toggle_show_hide_889F2)
    bpy.types.Object.sna_affected_objects_collection = bpy.props.CollectionProperty(name='Affected Objects Collection', description='Affected Objects and Cutter Objects', type=SNA_GROUP_sna_affected_objects_group)
    bpy.types.Object.sna_affected_objects_coll_indx = bpy.props.IntProperty(name='Affected Objects Coll Indx', description='Current affected object', default=0, subtype='NONE')
    bpy.types.Scene.sna_activate_face_align = bpy.props.BoolProperty(name='Activate Face Align', description='Turn on Face Center Snapping with Align Rotation while using Affect Only Origins temporarily', default=False, update=sna_update_sna_activate_face_align_2CC3A)
    bpy.types.Scene.sna_original_origin_state = bpy.props.BoolProperty(name='Original Origin State', description='The prior state before being modified', default=False)
    bpy.types.Scene.sna_original_snap_elements_base = bpy.props.EnumProperty(name='Original Snap Elements Base', description='The prior element base before being modified', items=[('INCREMENT', 'INCREMENT', 'Increment Snap to increments', 0, 1), ('GRID', 'GRID', 'Grid Snap to grid', 0, 2), ('VERTEX', 'VERTEX', 'Vertex Snap to vertices', 0, 4), ('EDGE', 'EDGE', 'Edge Snap to edges', 0, 8), ('FACE', 'FACE', 'Face Snap by projecting onto faces', 0, 16), ('VOLUME', 'VOLUME', 'Volume Snap to volume', 0, 32), ('EDGE_MIDPOINT', 'EDGE_MIDPOINT', 'Edge Center Snap to the middle of edges', 0, 64), ('EDGE_PERPENDICULAR', 'EDGE_PERPENDICULAR', 'Edge Perpendicular Snap to the nearest point on an edge', 0, 128), ('FACE_MIDPOINT', 'FACE_MIDPOINT', 'Face Center Snap to the middle of faces', 0, 256)], options={'ENUM_FLAG'})
    bpy.types.Scene.sna_original_use_snap = bpy.props.BoolProperty(name='Original Use Snap', description='The prior snap toggle before being modified', default=False)
    bpy.types.Scene.sna_original_snap_align_rotation = bpy.props.BoolProperty(name='Original Snap Align Rotation', description='The prior snap align rotation toggle before being modified', default=False)
    bpy.types.Scene.sna_original_use_snap_translate = bpy.props.BoolProperty(name='Original Use Snap Translate', description='The prior snap translate toggle before being modified', default=False)
    bpy.types.Scene.sna_palette_prop = bpy.props.PointerProperty(name='Palette_Prop', description='Palette used in the print prep extension', type=bpy.types.Palette)
    bpy.types.Scene.sna_random_transform_x = bpy.props.FloatProperty(name='Random Transform X', description='Used with Random Transform operator', default=100.0, subtype='DISTANCE', unit='LENGTH', min=0.0, soft_max=256.0, step=1, precision=0)
    bpy.types.Scene.sna_random_transform_y = bpy.props.FloatProperty(name='Random Transform Y', description='Used with Random Transform operator', default=100.0, subtype='DISTANCE', unit='LENGTH', min=0.0, soft_max=256.0, step=1, precision=0)
    bpy.types.Scene.sna_smart_pack_object_spacing = bpy.props.FloatProperty(name='Smart Pack Object Spacing', description='Gap between objects when packing', default=4.0, subtype='DISTANCE', unit='LENGTH', min=0.0, soft_max=10.0, step=10, precision=0)
    bpy.types.Scene.sna_smart_pack_group_spacing = bpy.props.FloatProperty(name='Smart Pack Group Spacing', description='Spacing between object groups when packing', default=30.0, subtype='DISTANCE', unit='LENGTH', min=1.0, soft_min=20.0, soft_max=80.0, step=10, precision=0)
    bpy.types.Scene.sna_smart_pack_bed_spacing = bpy.props.FloatProperty(name='Smart Pack Bed Spacing', description='Spacing from edge of print bed', default=4.0, subtype='DISTANCE', unit='LENGTH', min=0.0, soft_max=10.0, step=10, precision=0)
    bpy.types.Scene.sna_smart_pack_bed_length_x = bpy.props.FloatProperty(name='Smart Pack Bed Length X', description='Width of the Print Bed in the X Direction', default=256.0, subtype='DISTANCE', unit='LENGTH', min=1.0, soft_min=10.0, step=10, precision=0)
    bpy.types.Scene.sna_smart_pack_bed_length_y = bpy.props.FloatProperty(name='Smart Pack Bed Length Y', description='Width of the Print Bed in the Y Direction', default=256.0, subtype='DISTANCE', unit='LENGTH', min=1.0, soft_min=10.0, step=10, precision=0)
    bpy.types.Scene.sna_use_keyframes = bpy.props.BoolProperty(name='Use Keyframes', description='Use keyframes to preserve object location before moving them (Recommended)', default=True)
    bpy.types.Scene.sna_print_prep_start_frame = bpy.props.IntProperty(name='Print Prep Start Frame', description='First keyframe key for print prep', default=1, subtype='NONE')
    bpy.types.Scene.sna_print_prep_end_frame = bpy.props.IntProperty(name='Print Prep End Frame', description='Last keyframe key for print prep', default=250, subtype='NONE')
    bpy.types.Scene.sna_color_match = bpy.props.FloatProperty(name='Color Match', description='How much color affects object grouping during packing. \n0% = No matching \n100% = Exact color match', default=99.0, subtype='PERCENTAGE', unit='NONE', min=0.0, max=100.0, step=10, precision=0)
    bpy.utils.register_class(SNA_OT_Append_Printer_Proxy_160Ed)
    bpy.utils.register_class(SNA_OT_Use_Active_To_Cut_Selected_B4720)
    bpy.utils.register_class(SNA_OT_Remove_Cutter_66191)
    bpy.utils.register_class(SNA_OT_Delete_And_Remove_Cutter_From_All_Affected_Objects_B38B1)
    bpy.utils.register_class(SNA_OT_Select_Affected_Objects_Of_Cutter_231Cd)
    bpy.utils.register_class(SNA_OT_Select_Affected_Object_3E0D0)
    bpy.utils.register_class(SNA_OT_Update_Cutter_Affected_Objects_Collection_Edbc7)
    bpy.utils.register_class(SNA_OT_Add_Or_Update_Fdm_Material_37519)
    bpy.utils.register_class(SNA_OT_Smart_Pack_Beds_B19Df)
    bpy.utils.register_class(SNA_OT_Move_To_World_Origin_And_Clear_Rotation_F7F82)
    bpy.utils.register_class(SNA_OT_Select_Cutter_Object_D9844)
    bpy.utils.register_class(SNA_OT_Deselect_Object_Dbfbd)
    bpy.utils.register_class(SNA_OT_Activate_Object_81920)
    bpy.utils.register_class(SNA_OT_Set_Units_And_3D_View_Clipping_Be2D0)
    bpy.utils.register_class(SNA_AddonPreferences_88A14)
    bpy.utils.register_class(SNA_PT_PRINT_PREP_FEEEC)
    bpy.utils.register_class(SNA_PT_OBJECT_SELECTION_724EA)
    bpy.utils.register_class(SNA_PT_CUT_OBJECT_SETTINGS_04712)
    bpy.utils.register_class(SNA_PT_CUTTER_OBJECT_SETTINGS_FD083)
    bpy.utils.register_class(SNA_PT_SETUP_FOR_CUTTING_47B16)
    bpy.utils.register_class(SNA_PT_OBJECT_PLACEMENT_DF668)
    bpy.utils.register_class(SNA_PT_PRINTER_PROXY_47636)
    bpy.utils.register_class(SNA_PT_MATERIAL_SETTINGS_72DB7)
    bpy.utils.register_class(SNA_PT_VIDEO_TUTORIALS_B31D7)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_color_match
    del bpy.types.Scene.sna_print_prep_end_frame
    del bpy.types.Scene.sna_print_prep_start_frame
    del bpy.types.Scene.sna_use_keyframes
    del bpy.types.Scene.sna_smart_pack_bed_length_y
    del bpy.types.Scene.sna_smart_pack_bed_length_x
    del bpy.types.Scene.sna_smart_pack_bed_spacing
    del bpy.types.Scene.sna_smart_pack_group_spacing
    del bpy.types.Scene.sna_smart_pack_object_spacing
    del bpy.types.Scene.sna_random_transform_y
    del bpy.types.Scene.sna_random_transform_x
    del bpy.types.Scene.sna_palette_prop
    del bpy.types.Scene.sna_original_use_snap_translate
    del bpy.types.Scene.sna_original_snap_align_rotation
    del bpy.types.Scene.sna_original_use_snap
    del bpy.types.Scene.sna_original_snap_elements_base
    del bpy.types.Scene.sna_original_origin_state
    del bpy.types.Scene.sna_activate_face_align
    del bpy.types.Object.sna_affected_objects_coll_indx
    del bpy.types.Object.sna_affected_objects_collection
    del bpy.types.Object.sna_toggle_show_hide
    del bpy.types.Scene.sna_material_color
    del bpy.types.Scene.sna_add_material_to_cutter
    del bpy.types.Scene.sna_transfer_material
    del bpy.types.Scene.sna_hide_from_render
    del bpy.types.Scene.sna_hide_from_viewport
    del bpy.types.Scene.sna_boolean_solver
    del bpy.types.Scene.sna_cut_from_outside_only_rim
    del bpy.types.Scene.sna_even_thickness
    del bpy.types.Scene.sna_gap_direction
    del bpy.types.Scene.sna_cutter_gap
    bpy.utils.unregister_class(SNA_GROUP_sna_affected_objects_group)
    bpy.utils.unregister_class(SNA_OT_Append_Printer_Proxy_160Ed)
    bpy.utils.unregister_class(SNA_OT_Use_Active_To_Cut_Selected_B4720)
    bpy.utils.unregister_class(SNA_OT_Remove_Cutter_66191)
    bpy.utils.unregister_class(SNA_OT_Delete_And_Remove_Cutter_From_All_Affected_Objects_B38B1)
    bpy.utils.unregister_class(SNA_OT_Select_Affected_Objects_Of_Cutter_231Cd)
    bpy.utils.unregister_class(SNA_OT_Select_Affected_Object_3E0D0)
    bpy.utils.unregister_class(SNA_OT_Update_Cutter_Affected_Objects_Collection_Edbc7)
    bpy.utils.unregister_class(SNA_OT_Add_Or_Update_Fdm_Material_37519)
    bpy.utils.unregister_class(SNA_OT_Smart_Pack_Beds_B19Df)
    bpy.utils.unregister_class(SNA_OT_Move_To_World_Origin_And_Clear_Rotation_F7F82)
    bpy.utils.unregister_class(SNA_OT_Select_Cutter_Object_D9844)
    bpy.utils.unregister_class(SNA_OT_Deselect_Object_Dbfbd)
    bpy.utils.unregister_class(SNA_OT_Activate_Object_81920)
    bpy.utils.unregister_class(SNA_OT_Set_Units_And_3D_View_Clipping_Be2D0)
    bpy.utils.unregister_class(SNA_AddonPreferences_88A14)
    bpy.utils.unregister_class(SNA_PT_PRINT_PREP_FEEEC)
    bpy.utils.unregister_class(SNA_PT_OBJECT_SELECTION_724EA)
    bpy.utils.unregister_class(SNA_PT_CUT_OBJECT_SETTINGS_04712)
    bpy.utils.unregister_class(SNA_PT_CUTTER_OBJECT_SETTINGS_FD083)
    bpy.utils.unregister_class(SNA_PT_SETUP_FOR_CUTTING_47B16)
    bpy.utils.unregister_class(SNA_PT_OBJECT_PLACEMENT_DF668)
    bpy.utils.unregister_class(SNA_PT_PRINTER_PROXY_47636)
    bpy.utils.unregister_class(SNA_PT_MATERIAL_SETTINGS_72DB7)
    bpy.utils.unregister_class(SNA_PT_VIDEO_TUTORIALS_B31D7)
